import React from "react";

function StitchingStoreManagerDashboard() {
  return <div>StitchingStoreManagerDashboard</div>;
}

export default StitchingStoreManagerDashboard;
