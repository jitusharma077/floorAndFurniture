export const AllQcCheck = [
  {
    name: "Qc1",
    id: "1",
  },

  {
    name: "Qc2",
    id: "2",
  },

  {
    name: "Qc3",
    id: "3",
  },
];
